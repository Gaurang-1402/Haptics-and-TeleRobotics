plot(out.y.time, out.y.data)
xlabel("time (in seconds)")
ylabel("Output-y")
title("y vs. t(s)")